# Aerothon > 2025-04-07 2:18am
https://universe.roboflow.com/personal-bguwk/aerothon-w8zfy

Provided by a Roboflow user
License: CC BY 4.0

