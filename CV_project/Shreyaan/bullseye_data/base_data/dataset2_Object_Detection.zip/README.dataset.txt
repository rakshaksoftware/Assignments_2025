# Object_detection_target > 2025-04-07 2:12am
https://universe.roboflow.com/personal-bguwk/object_detection_target-iehxu

Provided by a Roboflow user
License: CC BY 4.0

