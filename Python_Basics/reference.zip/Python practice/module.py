#A file containing a set of functions you want to include in your application

def greeting(name):
  print("Hello, " + name) 
  
person1 = {
  "name": "John",
  "age": 36,
  "country": "Norway"
}

 
